<div>
    <form action="{{route("Blog.store")}}" method="post">
        <div class="mb-3">
            <label class="form-label" for="title">Title:</label>
            <input class="form-control" type="text" id="title" name="title"/>
        </div>
        <div class="mb-3">
            <label class="form-label" for="description">Description:</label>
            <input class="form-control" type="text" id="description" name="description"/>
        </div>
        <div class="mb-3">
            <label class="form-label" for="thumbnail">Thumbnail:</label>
            <input class="form-control" type="file" id="thumbnail" name="thumbnail"/>
        </div>
        <div class="mb-3">
            <label class="form-label" for="pdf">pdf(upto 15):</label>
            <input class="form-control" type="file" id="pdf" name="pdf[]" multiple/>
        </div>
    </form>
</div>
