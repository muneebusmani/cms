<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    function index()
    {
        return view("Blog.index");
    }

    function create()
    {
        return view("Blog.create");
    }

    function edit()
    {
        return view("Blog.edit");
    }

    function show()
    {
        return view("Blog.show");
    }

    function store(Request $request)
    {
        $data = $request->validate([
        ]);
        return 0;
    }

    function update(Request $request)
    {
        return 0;
    }

    function destroy(Request $request)
    {
        return 0;
    }
}
